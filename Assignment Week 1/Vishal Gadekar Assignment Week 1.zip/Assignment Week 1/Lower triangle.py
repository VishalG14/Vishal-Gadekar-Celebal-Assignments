n=int(input('Enter no. of rows for Lower Triangle:- '))
for i in range(1, n + 1):
        print('*' * i)